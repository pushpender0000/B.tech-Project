import csv
import boto3
import datetime


def detect_text(photo, bucket, acc_id, key):
    client = boto3.client('rekognition', aws_access_key_id=acc_id, aws_secret_access_key=key, region_name='ap-south-1')

    response = client.detect_text(Image={'S3Object': {'Bucket': bucket, 'Name': photo}})
    # response = client.detect_text(Image={'Bytes':photo}) #offline image

    textDetections = response['TextDetections']
    full_text = []
    # print('Detected text\n----------')
    for text in textDetections:
        # print('Detected text:' + text['DetectedText'])
        # print('Confidence: ' + "{:.2f}".format(text['Confidence']) + "%")
        # print('Id: {}'.format(text['Id']))
        if 'ParentId' in text:
            # print('Parent Id: {}'.format(text['ParentId']))
            if text['Confidence'] > 35:
                full_text.append(text['DetectedText'])
        # print('Type:' + text['Type'])
        # print()
    return full_text


def main():
    with open('aws_credentials.csv', 'r') as creds:
        next(creds)
        reader = csv.reader(creds)
        for line in reader:
            access_id = line[2]
            secret_access_key = line[3]
    '''
    #To get image from offline files
    with open('images/img1.jpg','rb') as img:
        img_bytes=img.read()'''
    bucket = 'hsn-rekognition-img'  # bucket_name
    s3 = boto3.resource('s3', aws_access_key_id=access_id, aws_secret_access_key=secret_access_key,
                        region_name='ap-south-1')

    my_bucket = s3.Bucket('hsn-rekognition-img')

    for file in my_bucket.objects.all():  # get all files from bucket
        row = []
        # print(file.key)
        if not file.key.lower().endswith(('.png', '.jpg', '.jpeg')):
            continue
        row.append(datetime.datetime.now())
        row.append(file.key)
        photo = file.key  # aws bucket file_name
        # text_list = detect_text(img_bytes, '', access_id, secret_access_key) #for_offline image detection
        text_list = detect_text(photo, bucket, access_id, secret_access_key)  # for s3 bucket
        print("List Text detected: ", text_list)
        row.append(' '.join(i for i in text_list))

        # write output in csv file offline
        with open('results.csv', 'a', newline='\n') as f:
            writer = csv.writer(f)
            writer.writerow(row)
            print('Text:\n', ' '.join(i for i in text_list))


if __name__ == "__main__":
    main()
